# GitHub Link

The assignment asks for a public GitHub repository link. This machine does not currently have `git` or GitHub publishing configured, so a live public URL could not be created directly from this environment.

Use this repo name for submission:

`financial-portfolio-manager`

Public GitHub link template:

`https://github.com/<your-github-username>/financial-portfolio-manager`

After uploading the files in this folder to your public GitHub repository, replace `<your-github-username>` with your actual username and include that final URL in the submission document.
