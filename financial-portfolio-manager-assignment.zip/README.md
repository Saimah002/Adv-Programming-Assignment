# Financial Portfolio Manager Assignment

## Files Included

- `portfolio_manager.ml`: Deliverable 1 OCaml implementation
- `deliverable_2_test_cases.ml`: executable test cases
- `deliverable_2_test_cases.md`: written test case summary
- `deliverable_3_report.md`: written report
- `github_link_template.md`: public GitHub link template

## Suggested GitHub Repository Name

`financial-portfolio-manager`

## Suggested Compilation Commands

If OCaml is installed on your machine, the project can be compiled with:

```powershell
ocamlc -c portfolio_manager.ml
ocamlc -o portfolio_manager.exe portfolio_manager.ml
ocamlc -o deliverable_2_test_cases.exe portfolio_manager.cmo deliverable_2_test_cases.ml
```

Then run:

```powershell
.\portfolio_manager.exe
.\deliverable_2_test_cases.exe
```
