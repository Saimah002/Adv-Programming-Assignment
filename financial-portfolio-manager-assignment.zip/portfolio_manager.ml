type stock = {
  symbol : string;
  quantity : float;
  purchase_price : float;
  current_price : float;
}

type portfolio = stock list

let normalize_symbol symbol =
  String.uppercase_ascii (String.trim symbol)

let make_stock symbol quantity purchase_price current_price =
  if String.trim symbol = "" then
    invalid_arg "Stock symbol cannot be empty"
  else if quantity <= 0.0 then
    invalid_arg "Quantity must be greater than zero"
  else if purchase_price < 0.0 || current_price < 0.0 then
    invalid_arg "Prices cannot be negative"
  else
    {
      symbol = normalize_symbol symbol;
      quantity;
      purchase_price;
      current_price;
    }

let rec add_stock stock portfolio =
  match portfolio with
  | [] -> [ stock ]
  | head :: tail ->
      if head.symbol = stock.symbol then
        stock :: tail
      else
        head :: add_stock stock tail

let rec remove_stock symbol portfolio =
  match portfolio with
  | [] -> []
  | head :: tail ->
      if head.symbol = normalize_symbol symbol then
        tail
      else
        head :: remove_stock symbol tail

let rec find_stock symbol portfolio =
  match portfolio with
  | [] -> None
  | head :: tail ->
      if head.symbol = normalize_symbol symbol then
        Some head
      else
        find_stock symbol tail

let rec update_price symbol new_price portfolio =
  if new_price < 0.0 then invalid_arg "New price cannot be negative"
  else
    match portfolio with
    | [] -> []
    | head :: tail ->
        if head.symbol = normalize_symbol symbol then
          { head with current_price = new_price } :: tail
        else
          head :: update_price symbol new_price tail

let stock_cost_basis stock =
  stock.quantity *. stock.purchase_price

let stock_market_value stock =
  stock.quantity *. stock.current_price

let stock_gain_loss stock =
  stock_market_value stock -. stock_cost_basis stock

let rec total_portfolio_value portfolio =
  match portfolio with
  | [] -> 0.0
  | head :: tail -> stock_market_value head +. total_portfolio_value tail

let rec total_cost_basis portfolio =
  match portfolio with
  | [] -> 0.0
  | head :: tail -> stock_cost_basis head +. total_cost_basis tail

let overall_gain_loss portfolio =
  total_portfolio_value portfolio -. total_cost_basis portfolio

let format_currency amount =
  Printf.sprintf "$%.2f" amount

let stock_to_string stock =
  Printf.sprintf
    "Symbol: %s | Quantity: %.2f | Purchase Price: %s | Current Price: %s | Gain/Loss: %s"
    stock.symbol
    stock.quantity
    (format_currency stock.purchase_price)
    (format_currency stock.current_price)
    (format_currency (stock_gain_loss stock))

let rec view_portfolio portfolio =
  match portfolio with
  | [] -> "Portfolio is empty."
  | [ stock ] -> stock_to_string stock
  | head :: tail -> stock_to_string head ^ "\n" ^ view_portfolio tail

let demo_portfolio () =
  let portfolio = [] in
  let portfolio = add_stock (make_stock "AAPL" 10.0 150.0 185.0) portfolio in
  let portfolio = add_stock (make_stock "MSFT" 8.0 290.0 325.0) portfolio in
  let portfolio = add_stock (make_stock "TSLA" 5.0 220.0 205.0) portfolio in
  let portfolio = update_price "TSLA" 210.0 portfolio in
  portfolio

let print_summary portfolio =
  Printf.printf "Financial Portfolio Manager\n";
  Printf.printf "----------------------------------------\n";
  Printf.printf "%s\n" (view_portfolio portfolio);
  Printf.printf "----------------------------------------\n";
  Printf.printf "Total Portfolio Value: %s\n"
    (format_currency (total_portfolio_value portfolio));
  Printf.printf "Overall Gain/Loss: %s\n"
    (format_currency (overall_gain_loss portfolio))

let () =
  let portfolio = demo_portfolio () in
  print_summary portfolio
