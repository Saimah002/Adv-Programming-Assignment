open Portfolio_manager

let epsilon = 0.0001

let assert_float_equal expected actual =
  if Float.abs (expected -. actual) > epsilon then
    failwith
      (Printf.sprintf "Expected %.4f but got %.4f" expected actual)

let assert_true condition message =
  if not condition then failwith message

let sample_portfolio =
  []
  |> add_stock (make_stock "AAPL" 10.0 150.0 185.0)
  |> add_stock (make_stock "MSFT" 8.0 290.0 325.0)
  |> add_stock (make_stock "GOOG" 6.0 120.0 135.0)

let test_add_stock () =
  let updated = add_stock (make_stock "NVDA" 4.0 700.0 875.0) sample_portfolio in
  match find_stock "NVDA" updated with
  | Some stock -> assert_float_equal 4.0 stock.quantity
  | None -> failwith "NVDA should be present after add_stock"

let test_remove_stock_existing () =
  let updated = remove_stock "MSFT" sample_portfolio in
  match find_stock "MSFT" updated with
  | Some _ -> failwith "MSFT should have been removed"
  | None -> assert_true true "MSFT removed successfully"

let test_remove_stock_missing () =
  let updated = remove_stock "AMZN" sample_portfolio in
  assert_float_equal
    (total_portfolio_value sample_portfolio)
    (total_portfolio_value updated)

let test_update_price_existing () =
  let updated = update_price "AAPL" 200.0 sample_portfolio in
  match find_stock "AAPL" updated with
  | Some stock -> assert_float_equal 200.0 stock.current_price
  | None -> failwith "AAPL should still be present after update"

let test_update_price_missing () =
  let updated = update_price "NFLX" 450.0 sample_portfolio in
  match find_stock "NFLX" updated with
  | Some _ -> failwith "NFLX should not be created by update_price"
  | None ->
      assert_float_equal
        (total_portfolio_value sample_portfolio)
        (total_portfolio_value updated)

let test_total_portfolio_value () =
  assert_float_equal 5250.0 (total_portfolio_value sample_portfolio)

let test_overall_gain_loss () =
  assert_float_equal 630.0 (overall_gain_loss sample_portfolio)

let test_empty_portfolio_view () =
  assert_true (view_portfolio [] = "Portfolio is empty.")
    "Empty portfolio should produce the expected message"

let run_test name test_fn =
  try
    test_fn ();
    Printf.printf "[PASS] %s\n" name
  with Failure message ->
    Printf.printf "[FAIL] %s -> %s\n" name message

let () =
  Printf.printf "Deliverable 2: Test Cases\n";
  Printf.printf "=========================\n";
  run_test "Add stock" test_add_stock;
  run_test "Remove existing stock" test_remove_stock_existing;
  run_test "Remove missing stock" test_remove_stock_missing;
  run_test "Update existing stock price" test_update_price_existing;
  run_test "Update missing stock price" test_update_price_missing;
  run_test "Total portfolio value calculation" test_total_portfolio_value;
  run_test "Overall gain/loss calculation" test_overall_gain_loss;
  run_test "Empty portfolio display" test_empty_portfolio_view
