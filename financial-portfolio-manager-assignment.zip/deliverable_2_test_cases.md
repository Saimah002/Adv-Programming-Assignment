## Deliverable 2: Test Cases

This deliverable documents the test coverage for the Financial Portfolio Manager implementation. The accompanying OCaml file `deliverable_2_test_cases.ml` contains executable tests written with simple assertions so the project stays lightweight and easy to submit.

### Function-by-function coverage

1. `make_stock`
- Verifies that a valid stock record can be created with symbol, quantity, purchase price, and current price.
- Guards against invalid data such as empty symbols, zero or negative quantity, and negative prices.

2. `add_stock`
- Confirms a new stock is added to the portfolio.
- Confirms a stock with an existing symbol is replaced, which keeps one authoritative entry for each symbol.

3. `remove_stock`
- Tests removing a stock that exists in the portfolio.
- Tests removing a stock that does not exist and confirms the portfolio remains unchanged.

4. `find_stock`
- Confirms an existing stock can be located by symbol.
- Confirms a missing stock returns `None`, which demonstrates the use of optional values and pattern matching.

5. `update_price`
- Tests updating the current price of a stock that exists.
- Tests updating a stock that is not in the portfolio and confirms that no unintended stock is created.
- Guards against negative replacement prices.

6. `total_portfolio_value`
- Verifies recursive aggregation of the market value of every stock in the portfolio.
- Confirms the base case on an empty portfolio returns `0.0`.

7. `overall_gain_loss`
- Verifies the total gain/loss equals total market value minus total cost basis.
- Confirms the recursive calculations are consistent with the expected sample values.

8. `view_portfolio`
- Confirms an empty portfolio returns the message `Portfolio is empty.`
- Confirms populated portfolios generate readable line-by-line output for all stocks.

### Edge cases required by the assignment

- Removing a stock that does not exist.
- Updating the price of a stock that is not in the portfolio.
- Handling an empty portfolio.
- Rejecting invalid input values before they enter the data structure.

### Expected sample values used in testing

- AAPL: 10 shares, purchase price `$150.00`, current price `$185.00`
- MSFT: 8 shares, purchase price `$290.00`, current price `$325.00`
- GOOG: 6 shares, purchase price `$120.00`, current price `$135.00`

From these values:

- Total portfolio value = `$5,250.00`
- Total cost basis = `$4,620.00`
- Overall gain/loss = `$630.00`

### Submission note

For course submission, this deliverable can be included as its own section after the implementation file or copied into the final compiled document alongside the report and GitHub link.
