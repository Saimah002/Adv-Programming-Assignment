$ErrorActionPreference = 'Stop'

function Escape-Xml {
    param([string]$s)
    $s = $s -replace '&', '&amp;' -replace '<', '&lt;' -replace '>', '&gt;' -replace '"', '&quot;'
    return $s
}

function Make-Docx {
    param([string]$Src, [string]$Dest)

    $content = Get-Content $Src -Raw
    $lines = $content -split "`n"

    $temp = Join-Path ([System.IO.Path]::GetTempPath()) ([System.IO.Path]::GetRandomFileName())
    New-Item -ItemType Directory -Path $temp | Out-Null
    New-Item -ItemType Directory -Path (Join-Path $temp '_rels') | Out-Null
    New-Item -ItemType Directory -Path (Join-Path $temp 'word') | Out-Null
    New-Item -ItemType Directory -Path (Join-Path $temp 'word/_rels') | Out-Null

    @"
<?xml version="1.0" encoding="UTF-8"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>
"@ | Out-File -LiteralPath (Join-Path $temp '[Content_Types].xml') -Encoding UTF8

    @"
<?xml version="1.0" encoding="UTF-8"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>
"@ | Out-File -LiteralPath (Join-Path $temp '_rels/.rels') -Encoding UTF8

    @"
<?xml version="1.0" encoding="UTF-8"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"/>
"@ | Out-File -LiteralPath (Join-Path $temp 'word/_rels/document.xml.rels') -Encoding UTF8

    $paragraphs = $lines | ForEach-Object {
        $escaped = Escape-Xml $_
        "<w:p><w:r><w:t xml:space=`"preserve`">$escaped</w:t></w:r></w:p>"
    }
    $body = ($paragraphs -join "")
    $docXml = "<?xml version=`"1.0`" encoding=`"UTF-8`" standalone=`"yes`"?>" +
        "<w:document xmlns:w=`"http://schemas.openxmlformats.org/wordprocessingml/2006/main`">" +
        "<w:body>$body<w:sectPr><w:pgSz w:w=`"12240`" w:h=`"15840`"/>" +
        "<w:pgMar w:top=`"1440`" w:right=`"1440`" w:bottom=`"1440`" w:left=`"1440`"/></w:sectPr></w:body></w:document>"
    $docXml | Out-File -LiteralPath (Join-Path $temp 'word/document.xml') -Encoding UTF8

    if (Test-Path $Dest) { Remove-Item $Dest }
    $zipPath = "$Dest.zip"
    if (Test-Path $zipPath) { Remove-Item $zipPath }
    Compress-Archive -Path (Join-Path $temp '*') -DestinationPath $zipPath -Force
    Move-Item $zipPath $Dest
    Remove-Item $temp -Recurse -Force
}

$targets = @(
    @{ Src = 'C:\Users\Puja Modi\Downloads\financial-portfolio-manager-assignment\deliverable_2_test_cases_report_1500_words.md'; Dest = 'C:\Users\Puja Modi\Downloads\financial-portfolio-manager-assignment\deliverable_2_test_cases_report_1500_words.docx' },
    @{ Src = 'C:\Users\Puja Modi\Downloads\financial-portfolio-manager-assignment\deliverable_3_report_1500_words.md'; Dest = 'C:\Users\Puja Modi\Downloads\financial-portfolio-manager-assignment\deliverable_3_report_1500_words.docx' }
)

foreach ($t in $targets) { Make-Docx -Src $t.Src -Dest $t.Dest }
